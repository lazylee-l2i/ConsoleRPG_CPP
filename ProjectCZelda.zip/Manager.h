#pragma once
#include "ZeldaCore.h"
#include "Item.h"
#include <Windows.h>


using namespace std;

class Actor;
struct Pos;

enum class MAPTYPE
{
	NORMAL_MAP,
	TOXIC_MAP,
	EVENT_MAP
};

enum class MAPVALUETYPE
{
	ROAD,
	OBSTACLE,
	EXIT
};

class GameManager
{
private:
	GameManager() {}
	GameManager(const GameManager& ref) {}
	GameManager& operator=(const GameManager& ref) {}
	~GameManager() { }

	map<string, shared_ptr<Actor>> actors;
	vector<shared_ptr<Item>> dropedItems;
	shared_ptr<Item> questBag = make_shared<Item>(2, Pos(0,0));
	bool* bGameState = nullptr;

public:
	static GameManager& GetInstance()
	{
		static GameManager GM;
		return GM;
	}
	// �ڵ忡�� ���� ������ �� ���
	void InsertActorInMap(Actor* actor);

	// �ڵ����� ���͸� n��ŭ �����ϰ� ���ִ� �޼ҵ�
	void AutoGenerateMonster(int n);

	// �����Ǳ� �� ��ֹ��̳� �̹� ������ ���Ϳ� ��ġ���� Ȯ���ϴ� �޼ҵ�
	bool PostCheckBeforeGenerateMonster(Pos monsterPos);

	// ���Ͱ� ������ ���� Ȯ���� ���� �������� �������ִ� �޼ҵ�
	void SpawnItemAfterMonsterDead(Pos pos);
	
	// �÷��̾ ���� �̵� �� �� ����ϴ� �޼ҵ�
	void PlayerMoveMap(Pos maxSize);

	const map<string, shared_ptr<Actor>> GetActors();
	shared_ptr<Actor> GetUser();
	shared_ptr<Actor> GetNPC();
	vector<shared_ptr<Actor>> GetMonster();
	shared_ptr<Item> GetInventory();
	vector<shared_ptr<Item>> GetDrop();

	void RemoveDeadActor(string name);
	void RemoveAllMonster();
	void RemoveFieldEntity();
	void RemoveItemFromPos(Pos pos);

	void ChangeGameState() { *this->bGameState = false; }

	bool bGetGameState() { return this->bGameState; }
	void SetGameState(bool* flag) { this->bGameState = flag; }
};



class MapManager
{
private:
	MapManager();
	MapManager(const MapManager& ref) {}
	MapManager& operator=(const MapManager& ref) {}
	~MapManager() {}
	bool PlayerAttack = false;
	vector<Pos> ObstacleVector;

	//===============  Map Data  ====================
	vector<vector<int>> DefaultMap;
	vector<vector<int>> BaseMap;
	vector<vector<int>> CopyMap;

	int SizeX = 0;
	int SizeY = 0;
	
	void GenerateMap();

	// Seperate Map Generator By MAPTYPE
	void GenNormalMap();
	void GenToxicMap();
	void GenEventMap();

	void GenObstacle();

	void RenderMap();

	// Cursor Move & Rewrite Screen method
	void MoveCursorToTopLeft();

	void FindAllObstaclePos();
	
	

public:
	static MapManager& GetInstance()
	{
		static MapManager MM;
		return MM;
	}
	void ShowMap();
	MAPVALUETYPE MapDataCheck(const Pos pos);
	bool EntityObstacleCheck(Pos& pos, string actorName="");

	Pos GetMapSize();
	int GetMapPosValue(Pos pos);
	const vector<Pos>& GetAllObstaclePos();
	
	void SetAttackTile(Pos pos);
	void SetAttackCall(bool flag) { this->PlayerAttack = flag; }
};

class InteractionManager
{
private:
	InteractionManager() {}
	InteractionManager(const InteractionManager& ref) {}
	InteractionManager& operator=(const InteractionManager& ref) {}
	~InteractionManager() {}
public:
	static InteractionManager& GetInstance()
	{
		static InteractionManager IM;
		return IM;
	}

	void CheckAllActorCollision();
	void CheckUserCollision();
	void CheckMonsterCollision();
	void CheckNPCCollision();
	void UserAttackMonster();
};

class UpdateManager
{
private:
	DIRECTION PlayerInput();
public:
	void PlayerUpdate();
	void PlayerUpdateLoop(bool* gamestate, double frametick);
	void NPCUpdate();
	void MonsterUpdate();
};