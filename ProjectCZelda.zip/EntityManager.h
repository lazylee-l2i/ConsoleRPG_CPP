#pragma once
#include "Entity.h"
#include "Actor.h"
#include "Item.h"
#include "Utill.h"

#include <vector>
#include <memory>

class Player;
class Item;

class EntityManager
{
	DECLARE_SINGLE(EntityManager)
private:
	// ������ unorederd_map���� �Ϸ��ߴµ�
	// �Ը� �۾Ƽ� �׳� vector�� ����
	vector<shared_ptr<Entity>> ActiveEntities;
	int monsterIndex = 0;
public:
	void CreateEntity(EEntityType type, const Pos& pos = Pos(0,0), const int _opt = 0);
	shared_ptr<Item> CreateRandomItem(const Pos& pos, const int _opt = 0);

	void RemoveEntityByName(const string& name);
	void RemoveAllByType(EEntityType type);
	void RemoveByPos(Pos pos);
	EInputType GetPlayerDirecion();
	shared_ptr<Player> GetPlayer();

	vector<shared_ptr<Entity>>& GetAllEntities();
	shared_ptr<Entity> FindEntityByName(const string& name);
	shared_ptr<Entity> FindEntityByPos(const Pos& pos);

};

