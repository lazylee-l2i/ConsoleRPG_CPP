#include "ZeldaCore.h"
#include "Manager.h"

void InteractionManager::CheckAllActorCollision()
{
	// Get All Actor Reference
	shared_ptr<Actor> player = GameManager::GetInstance().GetUser();
	shared_ptr<Actor> npc = GameManager::GetInstance().GetNPC();
	vector<shared_ptr<Actor>> monsters = GameManager::GetInstance().GetMonster();

	/*
	 �� �޼ҵ忡���� Collision���ø� üũ
	 ������ ���Ϳ��� �������� �� �ǰ� �̺�Ʈ��
	 ���Ϳ� ���Ͱ� ��ġ�� �ʰ� �и��ϴµ� ������ ��
	 User�� Attack�� �ٸ� �޼ҵ忡�� ����
	*/

	// User vs Monster Collision
	if (player != nullptr)
	{

	}

	// User vs NPC Collision
	if (npc != nullptr)
	{

	}

	// Monster to Monster Collision
	if (monsters.size() != 0)
	{

	}
}

// User vs (Monster or Item)
void InteractionManager::CheckUserCollision()
{
	shared_ptr<Actor> player = GameManager::GetInstance().GetUser();
	vector<shared_ptr<Actor>> monsters = GameManager::GetInstance().GetMonster();
	if (monsters.size() == 0)
		return;

	for (const auto monster : monsters)
	{
		if (player->GetPos() == monster->GetPos())
		{
			//player->SetHP(player->GetHP() - 1);
			player->ActorKnockBack(monster->GetDirectionByPos());
		}
	}

	vector<shared_ptr<Item>> Drops = GameManager::GetInstance().GetDrop();
	if (Drops.size() == 0)
		return;

	for (auto DropItem : Drops)
	{
		if (player->GetPos() == DropItem->GetItemPos())
		{
			Pos pos = player->GetPos();
			if (DropItem->GetItemName() == "heart")
			{
				player->SetHP(player->GetHP() + DropItem->GetItemEffectValue());
				GameManager::GetInstance().RemoveItemFromPos(pos);
				break;
			}
			else if (DropItem->GetItemName() == "Quest")
			{
				shared_ptr<Item> Qitem = GameManager::GetInstance().GetInventory();
				if (Qitem->GetItemCount() < Qitem->GetItemStackSize())
				{
					Qitem->PlusItemCount();
					if (Qitem->GetItemCount() == 10)
					{
						GameManager::GetInstance().ChangeGameState();
					}
					GameManager::GetInstance().RemoveItemFromPos(pos);
				}
				break;
			}
		}
	}
}

// Monster to Monster
void InteractionManager::CheckMonsterCollision()
{
	vector<shared_ptr<Actor>> monsters = GameManager::GetInstance().GetMonster();
	int size = monsters.size();
	for (int i = 0; i < size; i++)
	{
		for (int j = i + 1; j < size; j++)
		{
			if (monsters[i]->GetPos() == monsters[j]->GetPos())
			{
				Pos current = monsters[i]->GetPos();

				monsters[i]->ActorKnockBack();
				Pos After = monsters[i]->GetPos();
				if (not MapManager::GetInstance().EntityObstacleCheck(After, monsters[i]->GetName()))
				{
					monsters[i]->SetPos(current);
				}
			}
		}
	}
}

// User vs NPC
// NPC�� �������� �����Ƿ� �����������
// ���� NPC�� AI�� ���� �����̰� ������� Manager.cpp�� �����ϱ�
void InteractionManager::CheckNPCCollision()
{
}

void InteractionManager::UserAttackMonster()
{
	shared_ptr<Actor> user = GameManager::GetInstance().GetUser();
	vector<shared_ptr<Actor>> monsters = GameManager::GetInstance().GetMonster();

	for (auto monster : monsters)
	{
		if ((user->GetPos() + user->GetDirectionByPos()) == monster->GetPos())
		{
			monster->SetHP(monster->GetHP() - user->GetAttack());
			Pos current = monster->GetPos();

			monster->ActorKnockBack(user->GetDirectionByPos());
			Pos After = monster->GetPos();
			if (not MapManager::GetInstance().EntityObstacleCheck(After, monster->GetName()))
			{
				monster->SetPos(current);
			}

			if (monster->GetHP() <= 0)
			{
				GameManager::GetInstance().RemoveDeadActor(monster->GetName());
			}
		}
	}
}
