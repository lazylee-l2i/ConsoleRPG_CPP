#include "ZeldaCore.h"

using namespace std;



void Init()
{
	GameManager::GetInstance().InsertActorInMap(make_shared<Actor>(Actor("Player", Pos(5, 3), (int)5)));

}

void Update(UpdateManager* manager)
{
	manager->MonsterUpdate();
}

void Play()
{
	Init();

	bool* flag = new bool();
	*flag = true;
	GameManager::GetInstance().SetGameState(flag);

	GameTimer* timer = new GameTimer();
	timer->SetFrameTick(10);
	
	MapManager::GetInstance().ShowMap();

	UpdateManager* uManage = new UpdateManager();
	thread userInput(&UpdateManager::PlayerUpdateLoop, uManage, flag, timer->GetFrameTickTime());
	
	timer->LoopStart();
	MapManager::GetInstance().ShowMap();
	while (*flag)
	{	
		Sleep(timer->GetFrameTickTime());
		MapManager::GetInstance().ShowMap();
		if(timer->GetFrameCount() >= 10)
		{
			timer->LoopStart();
			Update(uManage);
			InteractionManager::GetInstance().CheckMonsterCollision();
		}
	}

	if (GameManager::GetInstance().GetInventory()->GetItemCount() == 10)
	{
		cout << "����� �̰���ϴ�." << endl;
	}

	userInput.join();

	delete flag;
	delete timer;
	delete uManage;
}

int main()
{
	srand(static_cast<unsigned int>(GetTickCount64()));
	Play();

	return 0;
}