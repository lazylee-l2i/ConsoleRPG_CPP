#pragma once
#include <unordered_map>
#include <mutex>

#define MAP_HEIGHT 21
#define MAP_WIDTH 31


#define AUTO_MOB_GEN_PERCENT 2
#define AUTO_OTC_GEN_PERCENT 10

#define PLAYER_SPAWNPOINT_X MAP_WIDTH / 2
#define PLAYER_SPAWNPOINT_Y MAP_HEIGHT / 2

#define GAME_FPS 10
#define UPDATE_DURATION_FRAME 10 

#define PLAYER_DEFAULT_MAXHP 10
#define PLAYER_TARGET_QUEST_COUNT 5



enum class EMapTileType
{
	ROAD,
	WALL,
	EXIT,
	ATTACK,
	PLAYER,
	PLAYER_GETHIT,
	PLAYER_DEAD,
	MONSTER,
	HEART,
	QUEST,
	MAXHEART,
	UNDEFINE
};

enum class EItemType
{
	HEART,
	QUEST,
	MAXHEART,
	BOMB,
	UNDEFINE
};

enum class EInputType
{
	UP,
	DOWN,
	LEFT,
	RIGHT,
	QUIT,
	ATTACKCALL,
	UNDEFINE,
	COMMAND_MODE
};

enum class EEntityType
{
	PLAYER,
	MONSTER,
	NPC,
	ITEM,
	UNDEFINE
};

static std::unordered_map<EMapTileType, const char*> tileSymbols = {
	{EMapTileType::ROAD,     "  "},
	{EMapTileType::WALL,     "��"},
	{EMapTileType::EXIT,     "��"},
	{EMapTileType::PLAYER,   "��"},
	{EMapTileType::MONSTER,  "��"},
	{EMapTileType::HEART,    "��"},
	{EMapTileType::MAXHEART, "��"},
	{EMapTileType::QUEST,    "��"},
	{EMapTileType::PLAYER_GETHIT, "��"},
	{EMapTileType::PLAYER_DEAD, "��"}
};

static std::unordered_map<EItemType, EMapTileType> itemSymbols = {
	{EItemType::HEART, EMapTileType::HEART},
	{EItemType::MAXHEART, EMapTileType::MAXHEART},
	{EItemType::QUEST, EMapTileType::QUEST}
};

static std::unordered_map<EInputType, const char*> attackSymbols = {
	{EInputType::UP,"��"},
	{EInputType::DOWN, "��"},
	{EInputType::LEFT, "��"}	,
	{EInputType::RIGHT,"��"}
};


struct Pos
{
	int x = 0;
	int y = 0;
	Pos() {}
	Pos(int x, int y);

	Pos& operator=(const Pos& other);
};

Pos operator+(const Pos& left, const Pos& right);

Pos operator-(const Pos& left, const Pos& right);

bool operator==(const Pos& left, const Pos& right);
bool operator!=(const Pos& left, const Pos& right);

int GetLengthAboutTwoPoint(const Pos& left, const Pos& right);




#define DECLARE_SINGLE(classname)					\
private:											\
	classname() {}									\
	classname(const classname& ref)	{}				\
	classname& operator=(const classname& ref) {}	\
	~classname() {}									\
public:												\
	static classname& GetInstance()					\
	{												\
		static classname s_instance;				\
		return s_instance;							\
	}														


#define GET_SINGLE(classname) classname::GetInstance()

#define SAFE_DELETE(_obj)	\
if (_obj)					\
{							\
	delete _obj;			\
	_obj = nullptr;			\
}							
